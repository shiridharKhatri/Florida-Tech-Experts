import { Mail, Phone, Linkedin } from "lucide-react"
import "./Footer.css"

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-brand">
            <h3>Florida Tech Experts</h3>
            <p>Professional web development services with guaranteed satisfaction.</p>
          </div>

          <div className="footer-contact">
            <h4>Get In Touch</h4>
            <div className="contact-links">
              <a href="mailto:contact@floridatechexperts.com" className="contact-link">
                <Mail size={18} />
                contact@floridatechexperts.com
              </a>
              <a href="tel:+1234567890" className="contact-link">
                <Phone size={18} />
                (123) 456-7890
              </a>
              <a href="https://linkedin.com/company/floridatechexperts" className="contact-link">
                <Linkedin size={18} />
                LinkedIn Profile
              </a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {new Date().getFullYear()} Florida Tech Experts. All rights reserved.</p>
          <p>Only Pay If Satisfied With Results</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
