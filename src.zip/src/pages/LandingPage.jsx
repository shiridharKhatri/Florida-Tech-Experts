import { Link } from "react-router-dom"
import { ArrowRight, Shield, Users, Award, CheckCircle } from "lucide-react"
import "./LandingPage.css"

const LandingPage = () => {
  return (
    <div className="landing-page">
      {/* Header */}
      <header className="landing-header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <Shield size={24} />
              <span>Florida Tech Experts</span>
            </div>
            <div className="header-actions">
              <Link to="/login" className="btn btn-outline">
                Login
              </Link>
              <Link to="/register" className="btn btn-primary">
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <div className="hero-text">
              <h1>Professional Web Development Platform</h1>
              <p className="hero-subtitle">Only Pay When Satisfied With Results</p>
              <p className="hero-description">
                Join our secure platform where clients and developers work together with complete transparency. Track
                projects, manage payments, and ensure satisfaction every step of the way.
              </p>

              <div className="hero-features">
                <div className="feature">
                  <CheckCircle size={20} />
                  <span>Escrow Payment Protection</span>
                </div>
                <div className="feature">
                  <CheckCircle size={20} />
                  <span>Real-time Project Tracking</span>
                </div>
                <div className="feature">
                  <CheckCircle size={20} />
                  <span>Satisfaction Guarantee</span>
                </div>
              </div>

              <div className="hero-actions">
                <Link to="/register" className="btn btn-primary btn-large">
                  Start Your Project
                  <ArrowRight size={20} />
                </Link>
                <Link to="/login" className="btn btn-outline">
                  Client Login
                </Link>
              </div>
            </div>

            <div className="hero-visual">
              <div className="platform-preview">
                <div className="preview-header">
                  <div className="preview-dots">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                  <span>Client Dashboard</span>
                </div>
                <div className="preview-content">
                  <div className="project-item">
                    <div className="project-status completed">Completed</div>
                    <h4>E-commerce Website</h4>
                    <div className="project-payment">
                      <Award size={16} />
                      <span>Payment Released</span>
                    </div>
                  </div>
                  <div className="project-item">
                    <div className="project-status in-progress">In Progress</div>
                    <h4>Landing Page</h4>
                    <div className="project-payment pending">
                      <Shield size={16} />
                      <span>Funds in Escrow</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features">
        <div className="container">
          <h2>Why Choose Our Platform?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <Shield size={40} />
              <h3>Secure Payments</h3>
              <p>Your money is held in escrow until you're completely satisfied with the work delivered.</p>
            </div>
            <div className="feature-card">
              <Users size={40} />
              <h3>Expert Developers</h3>
              <p>Work with verified professionals who have proven track records of delivering quality results.</p>
            </div>
            <div className="feature-card">
              <Award size={40} />
              <h3>Quality Guarantee</h3>
              <p>We stand behind our work. If you're not satisfied, you don't pay. It's that simple.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <div className="cta-content">
            <h2>Ready to Start Your Project?</h2>
            <p>Join hundreds of satisfied clients who trust our platform for their web development needs.</p>
            <Link to="/register" className="btn btn-primary btn-large">
              Create Your Account
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="landing-footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-brand">
              <div className="logo">
                <Shield size={24} />
                <span>Florida Tech Experts</span>
              </div>
              <p>Professional web development with guaranteed satisfaction.</p>
            </div>
            <div className="footer-links">
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2024 Florida Tech Experts. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage
